﻿namespace QueueViewApp
{
    internal class ChooseClinicForm
    {
        public ChooseClinicForm()
        {
        }
    }
}