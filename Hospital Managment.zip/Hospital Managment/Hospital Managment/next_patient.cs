﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Managment
{
    public partial class next_p_form : Form
    {
        public next_p_form()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        // Get next patient function
        static string SearchPatientByClinic(string attribute)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\CM\\Desktop\\New folder (2)\\Hospital Managment\\Hospital Managment\\Patients2.mdf\";Integrated Security=True;Connect Timeout=30";
            string query = "SELECT Pname FROM Patients WHERE PclincNo = @PclincNo";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@PclincNo", attribute);

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return reader["Pname"].ToString();
                    }
                }
            }

            // If no matching row is found, return null or handle accordingly
            return null;
        }

        // Delete next patient function
        static bool DeletePatientByClinic(string pname)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\CM\\Desktop\\New folder (2)\\Hospital Managment\\Hospital Managment\\Patients2.mdf\";Integrated Security=True;Connect Timeout=30";
            string query = "DELETE FROM Patients WHERE Pname = @Pname";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Pname", pname);

                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                // If at least one row is affected, consider it a success
                return rowsAffected > 0;
            }
        }

        private void next_p_form_Load(object sender, EventArgs e)
        {

        }

        private void back_next_pateint_Click(object sender, EventArgs e)
        {
            Application.OpenForms[1].Show();
            this.Close();
        }

        private void clinic1_Click(object sender, EventArgs e)
        {
            string name = SearchPatientByClinic("Dental Clinic");
            
            if (name != null)
            {
                new_p_label.Text = name;
            }
            else
            {
                new_p_label.Text = "There is no pateints in this clinic";
            }
        }

        private void internist_q_Click(object sender, EventArgs e)
        {
            string name = SearchPatientByClinic("Internist Clinic");

            if (name != null)
            {
                new_p_label.Text = name;
            }
            else
            {
                new_p_label.Text = "There is no pateints in this clinic";
            }
        }

        private void clinic3_Click(object sender, EventArgs e)
        {
            string name = SearchPatientByClinic("Orthopedic Clinic");

            if (name != null)
            {
                new_p_label.Text = name;
            }
            else
            {
                new_p_label.Text = "There is no pateints in this clinic";
            }
        }

        private void clinic4_Click(object sender, EventArgs e)
        {
            string name = SearchPatientByClinic("Eye Clinic");

            if (name != null)
            {
                new_p_label.Text = name;
            }
            else
            {
                new_p_label.Text = "There is no pateints in this clinic";
            }
        }

        private void new_p_label_Click(object sender, EventArgs e)
        {

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DeletePatientByClinic(new_p_label.Text);
        }
    }
}
