﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Managment
{
    public partial class add_new_patient : Form
    {
        public add_new_patient()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        
        readonly SqlConnection conn = new SqlConnection(connectionString: @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\CM\Desktop\New folder (2)\Hospital Managment\Hospital Managment\Patients2.mdf"";Integrated Security=True");

        private void patient_name_Click(object sender, EventArgs e)
        {

        }

        private void picture_name_Click(object sender, EventArgs e)
        {

        }

        private void Back_add_patient_Click(object sender, EventArgs e)
        {
            Application.OpenForms[1].Show();
            this.Close();
        }

        private void add_new_patient_Load(object sender, EventArgs e)
        {

        }


        private void sign_in_button_Click(object sender, EventArgs e) //add patinet button
        {

            try
            {
                if (text_name.Text == "" || textBox1.Text == "" || clinics_list.Text == " " || comboBox1.Text == " ")
                {
                    MessageBox.Show("Missing Info");
                }
                else
                {
                    string payment = "0";
                    if (clinics_list.Text == "Dental Clinic")
                    {
                        payment = "100";
                        MessageBox.Show("Your total bill is 100$");
                    }
                    else if (clinics_list.Text == "Internist Clinic") { payment = "200"; MessageBox.Show("Your total bill is 200$"); }
                    else if (clinics_list.Text == "Orthopedic Clinic") { payment = "300"; MessageBox.Show("Your total bill is 300$"); }
                    else if (clinics_list.Text == "Eye Clinic") { payment = "400"; MessageBox.Show("Your total bill is 400$"); }

                    conn.Open();

                    string name = text_name.Text.Trim();
                    string status = comboBox1.Text.Trim();
                    string phone = textBox1.Text;
                    string clinic = clinics_list.Text.Trim();
                    

                    string query = "INSERT INTO Patients (Pname, Pstatus, Pphone, PclincNo) VALUES (@Name, @Status, @Phone, @Clinic);" +
                    "INSERT INTO Payment (Pname, Pbill) VALUES (@pName, @Payment)"; ;
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@Name", name ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Status", status ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Phone", phone ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Clinic", clinic ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@pName", name ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Payment", payment ?? (object)DBNull.Value);
                        command.ExecuteNonQuery();
                    }

                    conn.Close();
                    MessageBox.Show("Reccord Entered Succesfully");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            text_name.Text = "";
            comboBox1.Text = "";
            clinics_list.Text = "";
            textBox1.Text = "";
        }

        private void text_name_TextChanged(object sender, EventArgs e)//patient name box
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)//patient phone box
        {

        }

        private void clinics_list_SelectedIndexChanged(object sender, EventArgs e) //clinic number box
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)//patient status box
        {

        }
    }
}
