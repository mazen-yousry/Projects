﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;      
using System.Data.SqlClient;


namespace Hospital_Managment
{
    public partial class sign_in_form : Form
    {
        // Get data from the database and put it in a dict
        static Dictionary<string, string> GetLoginData()
        {
            // Connection string for your database
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\CM\\Desktop\\New folder (2)\\Hospital Managment\\Databases\\Patients.mdf\";Integrated Security=True;Connect Timeout=30;Encrypt=False";

            // SQL query to retrieve data from the Login table
            string query = "SELECT * FROM Login";

            // Create a dictionary to store the login data
            Dictionary<string, string> loginData = new Dictionary<string, string>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open the database connection
                connection.Open();

                // Create a command to execute the SQL query
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Execute the SQL query and read the results
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Iterate through the results and populate the dictionary
                        while (reader.Read())
                        {
                            string username = reader["username"].ToString();
                            string password = reader["userpass"].ToString();
                            loginData.Add(username, password);
                        }
                    }
                }
            }

            return loginData;
        }

        static bool CheckCredentials(Dictionary<string, string> loginData, string enteredUsername, string enteredPassword)
        {
            // Iterate through all entries in the dictionary
            foreach (var entry in loginData)
            {
                string storedUsername = entry.Key;
                string storedPassword = entry.Value;

                // Check if the entered username and password match any entry in the dictionary
                if (enteredUsername == storedUsername && enteredPassword == storedPassword)
                {
                    // Valid credentials
                    return true;
                }
            }

            // Invalid credentials
            return false;
        }

        public sign_in_form()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void sign_in_button_Click_2(object sender, EventArgs e)
        {
            Dictionary<string, string> loginData = GetLoginData();

            string enteredUsername = text_name.Text; 
            string enteredPassword = text_password.Text; 

            if (CheckCredentials(loginData, enteredUsername, enteredPassword))
            {
                Main_form goToMain = new Main_form();
                goToMain.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("WRONG INFORMATIONS, PLEASE TRY AGAIN.");
            }
        }

        private void sign_in_form_Load(object sender, EventArgs e)
        {

        }

        private void Name_Click(object sender, EventArgs e)
        {

        }

        private void text_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Password_Click(object sender, EventArgs e)
        {

        }

        private void Welcome_Click(object sender, EventArgs e)
        {

        }


        private void picture_name_Click(object sender, EventArgs e)
        {

        }


        private void text_name_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void text_password_TextChanged(object sender, EventArgs e)
        {

        }


        private void text_name_TextChanged_2(object sender, EventArgs e)
        {

        }
    }
}
