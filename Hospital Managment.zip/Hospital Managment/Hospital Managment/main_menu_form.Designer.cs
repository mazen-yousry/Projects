﻿namespace Hospital_Managment
{
    partial class Main_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_form));
            this.label2 = new System.Windows.Forms.Label();
            this.ADD_New_P = new System.Windows.Forms.Button();
            this.lab = new System.Windows.Forms.Label();
            this.Clinics_Statistics = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.next_p = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.Home_menu_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.billibg_history = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(704, 326);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "Add New Patient";
            // 
            // ADD_New_P
            // 
            this.ADD_New_P.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ADD_New_P.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ADD_New_P.BackgroundImage")));
            this.ADD_New_P.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ADD_New_P.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ADD_New_P.Location = new System.Drawing.Point(688, 165);
            this.ADD_New_P.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ADD_New_P.Name = "ADD_New_P";
            this.ADD_New_P.Size = new System.Drawing.Size(195, 198);
            this.ADD_New_P.TabIndex = 4;
            this.ADD_New_P.Text = " ";
            this.ADD_New_P.UseVisualStyleBackColor = false;
            this.ADD_New_P.Click += new System.EventHandler(this.ADD_New_P_Click);
            // 
            // lab
            // 
            this.lab.AutoSize = true;
            this.lab.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lab.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab.Location = new System.Drawing.Point(485, 326);
            this.lab.Name = "lab";
            this.lab.Size = new System.Drawing.Size(118, 22);
            this.lab.TabIndex = 7;
            this.lab.Text = "Clinics Data";
            // 
            // Clinics_Statistics
            // 
            this.Clinics_Statistics.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Clinics_Statistics.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Clinics_Statistics.BackgroundImage")));
            this.Clinics_Statistics.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Clinics_Statistics.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Clinics_Statistics.Location = new System.Drawing.Point(447, 165);
            this.Clinics_Statistics.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Clinics_Statistics.Name = "Clinics_Statistics";
            this.Clinics_Statistics.Size = new System.Drawing.Size(199, 198);
            this.Clinics_Statistics.TabIndex = 6;
            this.Clinics_Statistics.Text = " ";
            this.Clinics_Statistics.UseVisualStyleBackColor = false;
            this.Clinics_Statistics.Click += new System.EventHandler(this.Clinics_Statistics_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(242, 326);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 22);
            this.label1.TabIndex = 9;
            this.label1.Text = "Next Patient";
            // 
            // next_p
            // 
            this.next_p.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.next_p.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("next_p.BackgroundImage")));
            this.next_p.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.next_p.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.next_p.Location = new System.Drawing.Point(212, 165);
            this.next_p.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.next_p.Name = "next_p";
            this.next_p.Size = new System.Drawing.Size(187, 198);
            this.next_p.TabIndex = 8;
            this.next_p.Text = " ";
            this.next_p.UseVisualStyleBackColor = false;
            this.next_p.Click += new System.EventHandler(this.next_p_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(340, 567);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 22);
            this.label5.TabIndex = 15;
            this.label5.Text = "Exit Program";
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Exit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Exit.BackgroundImage")));
            this.Exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Exit.Location = new System.Drawing.Point(311, 405);
            this.Exit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(187, 197);
            this.Exit.TabIndex = 14;
            this.Exit.Text = " ";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Home_menu_label
            // 
            this.Home_menu_label.AutoSize = true;
            this.Home_menu_label.BackColor = System.Drawing.Color.Transparent;
            this.Home_menu_label.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home_menu_label.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.Home_menu_label.Location = new System.Drawing.Point(432, 44);
            this.Home_menu_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Home_menu_label.Name = "Home_menu_label";
            this.Home_menu_label.Size = new System.Drawing.Size(217, 44);
            this.Home_menu_label.TabIndex = 17;
            this.Home_menu_label.Text = "Home Menu";
            this.Home_menu_label.Click += new System.EventHandler(this.Home_menu_label_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(599, 565);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 22);
            this.label3.TabIndex = 19;
            this.label3.Text = "Payment history";
            // 
            // billibg_history
            // 
            this.billibg_history.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.billibg_history.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("billibg_history.BackgroundImage")));
            this.billibg_history.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.billibg_history.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.billibg_history.Location = new System.Drawing.Point(579, 405);
            this.billibg_history.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.billibg_history.Name = "billibg_history";
            this.billibg_history.Size = new System.Drawing.Size(195, 197);
            this.billibg_history.TabIndex = 18;
            this.billibg_history.Text = " ";
            this.billibg_history.UseVisualStyleBackColor = false;
            this.billibg_history.Click += new System.EventHandler(this.billibg_history_Click);
            // 
            // Main_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1091, 678);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.billibg_history);
            this.Controls.Add(this.Home_menu_label);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.next_p);
            this.Controls.Add(this.lab);
            this.Controls.Add(this.Clinics_Statistics);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ADD_New_P);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Main_form";
            this.Text = "Main menu";
            this.Load += new System.EventHandler(this.Main_form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ADD_New_P;
        private System.Windows.Forms.Label lab;
        private System.Windows.Forms.Button Clinics_Statistics;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button next_p;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label Home_menu_label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button billibg_history;
    }
}

